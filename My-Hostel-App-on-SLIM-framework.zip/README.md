# My-Hostel-App-on-SLIM-framework
Re-engineering Restful APIs for My Hostel App on SLIM framework
